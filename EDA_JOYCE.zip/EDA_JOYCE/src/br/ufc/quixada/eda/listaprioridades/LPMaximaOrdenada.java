package br.ufc.quixada.eda.listaprioridades;

import java.util.List;

//JOYCE NAYNE ARAUJO NASCIMENTO 383868

/**
 * Implementa a lista de prioridade usando vetor ordenado.
 * Reparem que aqui voc� devem utilizar obrigat�riamente o quickSort 
 * para realizar a ordena��o, quando for necess�rio.
 * @author fabio
 *
 */
public class LPMaximaOrdenada {
	private int nMaximo = 0;
	private int vetor[] = null;
	private int n = 0;
	
	public LPMaximaOrdenada(int Nmaximo){
		nMaximo = Nmaximo;
		vetor = new int[Nmaximo];
	}
	
	public void contruir(List<Integer> entrada){
		for(int i = 0; i < entrada.size(); i++){
			vetor[i] = entrada.get(i);
		}
		n = entrada.size();
		quickSort(vetor, 0, n);
	}
	
	public int getMaximaPrioridade(){
		int maxima = vetor[n - 1];
		return maxima;
	}
	
	public int remove(){
		n--;
		return vetor[n - 1];
	}	
	
	public void inserir(int prioridade){
		if(n + 1 <= nMaximo){
			vetor[n] = prioridade;
			n++;
		}
		quickSort(vetor, 0, n);
		
	}
	
	public void alterarPrioridade(int prioridade, int novaPrioridade){ 
		for(int i = 0; i < n; i++){
			if(vetor[i] == prioridade){
				vetor[i] = novaPrioridade;
				break;
			}
		}
		quickSort(vetor, 0, n);
	}
	
	private void quickSort(int vetor[], int ini, int fim){
		 if(ini < fim){
             int posicaoPivo = particiona(vetor, ini, fim);
             quickSort(vetor, ini, posicaoPivo - 1);
             quickSort(vetor, posicaoPivo + 1, fim);
		 }		
	}
	
	private int particiona(int vetor[], int p, int r){		
        int pivo = vetor[r];
        int i = p - 1;
        for(int j = p; j <= r - 1; j++){
        	if (vetor[j] <= pivo){
        		i++;
        		int aux = vetor[i];
        		vetor[i] = vetor[j];
        		vetor[j] = aux;
        	}
        }
        
        int aux = vetor[i + 1];
        vetor[i + 1] = vetor[r];
        vetor[r] = aux;
        return i + 1;
	}
	
	public void mostrar(){
		int prioridade = n - 1; 
		System.out.println("Prioridade máxima = " + prioridade + " tamanho do vetor = " + n + ".");
		for(int i = 0; i < n; i++){
			System.out.print(vetor[i] + ", ");
		}
	}
}
