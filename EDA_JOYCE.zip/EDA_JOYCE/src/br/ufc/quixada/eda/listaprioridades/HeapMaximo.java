package br.ufc.quixada.eda.listaprioridades;

import java.util.List;

//JOYCE NAYNE ARAUJO NASCIMENTO 383868

/**
 * Implementa a lista de prioridade usando Heap Maximo.
 * @author fabio
 *
 */
public class HeapMaximo {
	private int nMaximo = 0;
	private int vetor[] = null;
	private int n = 0;
	
	public HeapMaximo(int Nmaximo){
		nMaximo = Nmaximo;
		vetor = new int[Nmaximo];
	}
	
	private void subir(int i){
		int j = i / 2;
		if(j >= 1){
			if(vetor[j] < vetor[i]){
				int aux = vetor[j];
				vetor[j] = vetor[i];
				vetor[i] = aux;
				subir(j);
			}
		}
	}
	
	private void descer(int i){
		int j = 2 * i;
		if((j <= n) && (j+1 <= n)){
			if(vetor[j + 1] > vetor[j]){
				j++;
			}
			if(vetor[j] > vetor[i]){
				int aux = vetor[j];
				vetor[j] = vetor[i];
				vetor[i] = aux;
				descer(j);
			}
		}
		
	}
	
	public void contruir(List<Integer> entrada){
		n = entrada.size();
		for(int i = n / 2; i >= 1; i--){
			vetor[i] = entrada.get(i);
			descer(i);
		}
	}
	
	public int getMaximaPrioridade(){
		int max_prioridade = 0;
		for(int i = 0; i < n; i++){
			if(vetor[i] > vetor[max_prioridade]){
				max_prioridade = i;
			}
		}
		return vetor[max_prioridade];
	}
	
	public int remove(){
		if(n >= 1){
			int aux = vetor[1];
			vetor[1] = vetor[n];
			vetor[n] = aux;
			n--;
			descer(1);
			return aux;
		}
		return 0;
	}	
	
	public void inserir(int prioridade){
		if(n + 1 <= nMaximo){
			vetor[n + 1] = prioridade;
			n++;
			subir(n);
		}
	}
	
	public void alterarPrioridade(int prioridade, int novaPrioridade){
		for(int i = 0; i < n; i++){
			if(vetor[i] == prioridade){
				vetor[i] = novaPrioridade;
				descer(i);
			}
		}
		
	}	
}
